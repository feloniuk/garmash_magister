<?php $__env->startSection('content'); ?>
    <div class="container">
    <!-- Page Header -->
    <div class="page-header row no-gutters py-4">
        <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
            <h3 class="page-title">Замовлення #<?php echo e($order->id); ?></h3>
        </div>
    </div>
    <?php if($message = session('message')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>
    <!-- End Page Header -->
    <!-- Default Light Table -->
    <div class="row">
        <div class="col">
            <div class="card card-small mb-4">
                <div class="card-header border-bottom">
                    <p>Інформація про клієнта</p>
                </div>
                <div class="card-body p-0 pb-3 text-center">
                    <table class="table mb-0">
                        <thead class="bg-light">
                        <tr>
                            <th scope="col" class="border-0">#</th>
                            <th scope="col" class="border-0">Ім'я</th>
                            <th scope="col" class="border-0">Email</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $order->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="card card-small mb-4">
                <div class="card-header border-bottom">
                    <p>Інформація про замовлення</p>
                </div>
                <div class="card-body p-0 pb-3 text-center">
                    <table class="table mb-0">
                        <thead class="bg-light">
                        <tr>
                            <th scope="col" class="border-0">#</th>
                            <th scope="col" class="border-0">Продукція</th>
                            <th scope="col" class="border-0">Кількість (шт)</th>
                            <th scope="col" class="border-0">Ціна (грн)</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product[0]->id); ?></td>
                                <td><?php echo e($product[0]->title); ?></td>
                                <td><?php echo e($product[0]->amount); ?></td>
                                <td><?php echo e($product[0]->price); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="p-2 d-flex justify-content-between" style="width: 800px;margin: 0 auto;font-size: 25px;">
                        <p>Загальна вартість:</p>
                        <div style="color: green;"><?php echo e($order->orderSum); ?> грн</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Default Light Table -->
    <div class="row">
        <div class="col">
            <form class="justify-content-between" action="<?php echo e(route('orders.update', $order->id)); ?>" method="post">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Статус</label>
                    <select class="form-control" name="status" id="exampleFormControlSelect1">
                        <option <?php if($order->status == 'active'): ?> selected <?php endif; ?> value="active">Нове</option>
                        <option <?php if($order->status == 'apply'): ?> selected <?php endif; ?> value="apply">Прийняте</option>
                        <option <?php if($order->status == 'reject'): ?> selected <?php endif; ?> value="reject">Відхилено</option>
                    </select>
                    <?php if($errors->has('status')): ?>
                        <div style="color: #ff2432" role="alert">
                            <?php echo e($errors->first('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Коментарій</label>
                    <textarea class="form-control" name="comment" id="exampleFormControlTextarea1" rows="3"><?php echo e($order->comment); ?></textarea>
                    <?php if($errors->has('comment')): ?>
                        <div style="color: #ff2432" role="alert">
                            <?php echo e($errors->first('comment')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-success">Зберегти</button>
            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\garmash\resources\views/orders_view.blade.php ENDPATH**/ ?>