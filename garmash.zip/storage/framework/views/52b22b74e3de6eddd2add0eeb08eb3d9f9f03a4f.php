<?php $__env->startSection('content'); ?>
    <style>
        @import  url('https://fonts.googleapis.com/css2?family=Manrope:wght@200&display=swap');

        body {
            font-family: 'Manrope', sans-serif;
            background:#eee;
        }

        .size span {
            font-size: 11px;
        }

        .color span {
            font-size: 11px;
        }

        .product-deta {
            margin-right: 70px;
        }

        .gift-card:focus {
            box-shadow: none;
        }

        .pay-button {
            color: #fff;
        }

        .pay-button:hover {
            color: #fff;
        }

        .pay-button:focus {
            color: #fff;
            box-shadow: none;
        }

        .text-grey {
            color: #a39f9f;
        }

        .qty i {
            font-size: 11px;
        }
        .amount-button {
            font-size: 35px;
            cursor: pointer;
            margin-left: 15px;
        }
    </style>
    <div class="container mt-5 mb-5">
        <div class="d-flex justify-content-center row">
            <?php if($order): ?>
                <div class="col-md-8">
                    <div class="p-2">
                        <h4>Замовлення</h4>
                    </div>
                    <div class="alert alert-success" role="alert" id="order-alert" style="display: none;">
                    </div>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex flex-row justify-content-between align-items-center p-2 bg-white mt-4 px-3 rounded">
                            <div class="mr-1"><img class="rounded" src="<?php echo e(asset('images/products/' . $product['image'])); ?>" width="150"></div>
                            <div class="d-flex flex-column align-items-center product-details">
                                <span class="font-weight-bold"><?php echo e($product['name']); ?> / 100г</span>
                            </div>
                            <div class="d-flex flex-row align-items-center qty">
                                <h5 class="text-grey mt-1 mr-1 ml-1" id="amount-product-<?php echo e($product['id']); ?>"><?php echo e($product['amount']); ?></h5>
                            </div>
                            <div>
                                <span class="amount-button" onclick="changeAmount('<?php echo e($product['id']); ?>', '+')">+</span>
                                <span class="amount-button" onclick="changeAmount('<?php echo e($product['id']); ?>', '-')">-</span>
                            </div>
                            <div>
                                <h5 class="text-grey" id="sum-product-<?php echo e($product['id']); ?>"><?php echo e(round($product['price'] * $product['amount'], 2)); ?>грн</h5>
                            </div>
                            <div class="d-flex align-items-center"><i class="fa fa-trash mb-1 text-danger" style="cursor: pointer;" onclick="removeProduct('<?php echo e($product['id']); ?>')"></i></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2 d-flex justify-content-between">
                        <h4>Загальна вартість:</h4>
                        <div style="color: green; font-size: 30px;font-weight: bold;" id="full-price"><?php echo e($fullPrice); ?>грн</div>
                    </div>

                    <div class="d-flex flex-row align-items-center mt-3 p-2 bg-white rounded"><button class="btn btn-warning btn-block btn-lg ml-2 pay-button" onclick="makeOrder();" id="order-btn" type="button">Відправити замовлення</button></div>
                </div>
            <?php else: ?>
                <h3>Ваше замовлення порожнє :(</h3>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    function changeAmount(productId, operation)
    {
        $.ajax({
            url: '<?php echo e(route('product.change-amount')); ?>',
            method: 'post',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {productId: productId, operation: operation},
            dataType: 'json',
            success: function(data){
                if (data['error']) {
                    alert(data['error']);
                    return;
                }
                if (data['redirect']) {
                    window.location.href = "<?php echo e(route('product.cart')); ?>";
                }
                $('#sum-product-' + data.productId).html(data.sum + 'грн');
                $('#amount-product-' + data.productId).html(data.amount);
                $('#full-price').html(data.fullPrice + 'грн');
            }
        });
    }

    function removeProduct(productId)
    {
        $.ajax({
            url: '<?php echo e(route('product.remove')); ?>',
            method: 'post',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {productId: productId},
            dataType: 'json',
            success: function(data){
                window.location.href = "<?php echo e(route('product.cart')); ?>";
            }
        });
    }

    function makeOrder()
    {
        $.ajax({
            url: '<?php echo e(route('product.create-order')); ?>',
            method: 'post',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            dataType: 'json',
            success: function(data){
                if (data['success']) {
                    let alertBlock = $('#order-alert');
                    $('#order-btn').prop('disabled', true);
                    alertBlock.css('display', 'block')
                    alertBlock.html('Ваше замовлення успішно створене!');
                } else {
                    alert('some error')
                }
            }
        });
    }
</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\garmash\resources\views/cart.blade.php ENDPATH**/ ?>