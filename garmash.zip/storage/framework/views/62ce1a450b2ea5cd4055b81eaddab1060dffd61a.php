<?php $__env->startSection('content'); ?>
        <div class="container pt-5">
            <div class="row justify-content-center">
                <div class="col-md-8 order-md-2 col-lg-9">
                    <div class="container-fluid">
                        <div class="row">
                            <h3>Каталог сировини</h3>
                            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md-6 col-lg-4 mb-3">
                                <div class="card h-100 border-0">
                                    <div class="card-body text-center">
                                        <h4 class="card-title">
                                            <a  class=" font-weight-bold text-dark text-uppercase small"><?php echo e($product->title); ?></a>
                                        </h4>



                                        <p><?php echo e($product->price); ?>грн/1кг</p>
                                    </div>
                                    <?php if($product->ordered): ?>
                                        <button type="button" id="add-button-<?php echo e($product->id); ?>" class="btn btn-success" disabled>Вже додано</button>
                                    <?php else: ?>
                                        <button type="button" id="add-button-<?php echo e($product->id); ?>" onclick="addProduct('<?php echo e($product->id); ?>');" class="btn btn-success">Додати до замовлення</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            function addProduct(productId)
            {
                $.ajax({
                    url: '<?php echo e(route('material.add')); ?>',
                    method: 'post',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {productId: productId},
                    dataType: 'json',
                    success: function(data){
                        if (data['error']) {
                            alert(data['error']);
                            return;
                        }
                        let btn = $('#add-button-' + data);
                        btn.prop('disabled', true);
                        btn.html('Вже додано');
                        alert('Сировину додано до замовлення');
                    }
                });
            }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WORK\garmash\resources\views/materials.blade.php ENDPATH**/ ?>